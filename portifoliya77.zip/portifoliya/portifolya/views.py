from .forms import SendMessageForm
from django.shortcuts import render
from django.core.exceptions import ValidationError


def index(request):
    form = SendMessageForm(request.POST)
    if form.is_valid():
        form.save()
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        subject = request.POST.get('subject')
        message = request.POST.get('message')

        if not name or not email or not subject or not message:
            raise ValidationError('Some fields are required.')

    return render(request, 'index.html', {'form': form})
