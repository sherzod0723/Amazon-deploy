from django import forms
from .models import SendMessage


class SendMessageForm(forms.ModelForm):
    class Meta:
        model = SendMessage
        fields = ['name', 'email', 'subject', 'message']
