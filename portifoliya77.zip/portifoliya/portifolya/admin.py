from django.contrib import admin
from .models import SendMessage

admin.site.register(SendMessage)



